__version__ = "0.1.6"
__author__ = "M_O_D_E_R"

from .types_ import *
from .Core import core
from .Core import exceptions_
from .Core import operations_
